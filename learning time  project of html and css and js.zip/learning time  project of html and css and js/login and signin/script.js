// No JS , just html & css

// I have created a html & code working example of Paul's design - feel free to use https://dribbble.com/shots/2125879-Day-001-Login-Form