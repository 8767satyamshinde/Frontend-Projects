// Drawback 1: input and label have a semantically incoret order
// Drawback 2: you cannot use the full potential of html5 validation built in validation features like `<input type="email" />`