/*
  Pure CSS: Select
  - Wrapper div to apply the arrow
*/