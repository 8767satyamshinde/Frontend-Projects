// Pure CSS custom checkboxes.

// Reference: https://css-tricks.com/snippets/css/custom-checkboxes-and-radio-buttons/
// and: http://www.456bereastreet.com/archive/201211/accessible_custom_checkboxes_and_radio_buttons/