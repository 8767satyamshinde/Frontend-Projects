// a small keyboard
// I found that there were not a lot of keyboards on codepen
// So I figured I'd try my hand at it VUALA!
// & dat flatUI Doe