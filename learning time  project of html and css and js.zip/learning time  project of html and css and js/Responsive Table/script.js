// The original responsive design is taken from Geoff Yuen here: https://codepen.io/geoffyuen/pen/FCBEg

// Geoff Yuen gave credit as follows: Thanks to @leefroese for suggestion about data attributes

// I loved his mobile design, but changed some of the styling to match up with what I wanted. I'm also not using SCSS or anything else; just HTML and CSS.