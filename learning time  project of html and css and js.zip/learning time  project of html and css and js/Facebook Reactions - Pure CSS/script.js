// Facebook Reactions - Pure CSS

// Press Tab to use with accessibility

// Instagram: @deividmarques
// github: https://github.com/deividmarques/facebook-reactions-css
// twitter: @deividmarques