// Nothing to see here!

// Oh, If you want a more organized code just visit the GitHub repository: https://github.com/moPsych/hills