//Inpired by this pen from Jhey:
//https://codepen.io/jh3y/pen/bGYoEwX