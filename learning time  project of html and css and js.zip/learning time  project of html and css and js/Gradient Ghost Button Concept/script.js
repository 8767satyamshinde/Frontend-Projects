/*

Pure CSS experiment with gradient borders and text on transparent background.

Background photo by http://unsplash.com

*/